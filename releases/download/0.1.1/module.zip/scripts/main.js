Hooks.once('diceSoNiceInit', (dice3d) => {
    dice3d.addTexture("Beans1", {
        name: "Beans1",
        composite: "source-over",
        source: "modules/bean-dice/beans/beans1.jpg",
        bump:""
    });
});
